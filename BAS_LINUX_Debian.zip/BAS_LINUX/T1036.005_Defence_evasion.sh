#!/bin/bash

# Ensure the output directory exists
output_dir="./Linux_output/Defence_Evasion"
mkdir -p "$output_dir"

# Output file
output_file="$output_dir/T1036.005_Defence_evasion.txt"

# Input parameters
test_message="Hello from the SISA test T1036.005#1"

# Create the masquerading directory
mkdir -p "$HOME/..."

# Copy the system shell executable (sh) to the masquerading directory
cp "$(which sh)" "$HOME/..."

# Execute a command using the copied shell from the masquerading directory
echo "Executing command using the copied shell:" | tee -a "$output_file"
$HOME/.../sh -c "echo $test_message" | tee -a "$output_file"

# Cleanup: Remove the copied shell and the masquerading directory
rm -f "$HOME/.../sh"
rmdir "$HOME/..."

# Print completion message
echo "Execution completed. Output saved to $output_file" | tee -a "$output_file"
