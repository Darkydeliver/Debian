#!/bin/bash

# Atomic Test #8 - Create local account (Linux)
create_local_account() {
    local username="art"
    local password=$(openssl passwd -1 art)
    
    # Check if user 'art' already exists
    if id "$username" &>/dev/null; then
        echo "User 'art' already exists. Skipping creation."
    else
        # Create the user 'art' with /bin/bash shell and home directory
        if [ "$(uname)" = 'Linux' ]; then
            useradd --shell /bin/bash --create-home --password $password $username
        elif [ "$(uname)" = 'FreeBSD' ]; then
            pw useradd $username -g wheel -s /bin/sh
            echo $password | pw mod user $username -h 0
        else
            echo "Unsupported platform $(uname)"
            return 1
        fi
    fi
    
    # Switch to user 'art', execute whoami, and exit
    su $username -c "whoami; exit"
    
    # Cleanup: Delete user 'art'
    if [ "$(uname)" = 'Linux' ]; then
        userdel $username -rf
    elif [ "$(uname)" = 'FreeBSD' ]; then
        rmuser -y $username
    fi
}

# Atomic Test #9 - Reactivate a locked/expired account (Linux)
reactivate_account() {
    local username="art"
    local password=$(openssl passwd -1 art)
    
    # Create the user 'art' if it does not exist
    if ! id "$username" &>/dev/null; then
        if [ "$(uname)" = 'Linux' ]; then
            useradd --shell /bin/bash --create-home --password $password $username
        elif [ "$(uname)" = 'FreeBSD' ]; then
            pw useradd $username -g wheel -s /bin/sh
            echo $password | pw mod user $username -h 0
        else
            echo "Unsupported platform $(uname)"
            return 1
        fi
    fi
    
    # Lock and expire the account, then unlock and renew it
    usermod --lock $username
    usermod --expiredate "1" $username
    usermod --unlock $username
    usermod --expiredate "99999" $username
    
    # Switch to user 'art', execute whoami, and exit
    su $username -c "whoami; exit"
    
    # Cleanup: Delete user 'art'
    userdel -r $username
}

# Atomic Test #11 - Login as nobody (Linux)
login_as_nobody() {
    local username="nobody"
    local password=$(openssl passwd -1 nobody)
    
    # Change login shell of 'nobody' to /bin/bash
    chsh --shell /bin/bash $username
    
    # Change password of 'nobody' to 'nobody'
    usermod --password $password $username
    
    # Switch to user 'nobody', execute whoami, and exit
    su $username -c "whoami; exit"
    
    # Reset 'nobody' shell to /usr/sbin/nologin
    chsh --shell /usr/sbin/nologin $username
}

# Main script execution
echo "Running SISA Test - Technique: T1078.003 #1 - Create local account (Linux)"
create_local_account

echo "Running SISA Test - Technique: T1078.003 #2 - Reactivate a locked/expired account (Linux)"
reactivate_account

echo "Running SISA Test - Technique: T1078.003 #3 - Login as nobody (Linux)"
login_as_nobody

echo "Tests completed."
