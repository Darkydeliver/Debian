#!/bin/bash

# Function to remove files and directories created by the `at` scheduler script
cleanup_at_scheduler() {
    echo "Cleaning up 'at' scheduler artifacts..."
    output_folder="./Linux_output/Execution/T1053.002_Execution.txt"
    if [ -f "$output_folder" ]; then
        rm "$output_folder"
        echo "Removed: $output_folder"
    fi
    # Additional cleanup related to `at` jobs (if any)
    atrm $(atq | awk '{print $1}') 2>/dev/null
    echo "'at' scheduler cleanup complete."
}

# Function to remove cron job artifacts
cleanup_cron_jobs() {
    echo "Cleaning up cron job artifacts..."
    cron_files=("/tmp/persistevil" "/etc/cron.daily/persistevil" "/etc/cron.hourly/persistevil" "/etc/cron.monthly/persistevil" "/etc/cron.weekly/persistevil" "/etc/cron.d/persistevil" "/var/spool/cron/crontabs/persistevil")
    
    for file in "${cron_files[@]}"; do
        if [ -f "$file" ]; then
            sudo rm -f "$file"
            echo "Removed: $file"
        fi
    done
    if [ -f "/tmp/notevil" ]; then
        sudo crontab /tmp/notevil
        sudo rm /tmp/notevil
        echo "Restored original crontab and removed /tmp/notevil."
    fi
    echo "Cron job cleanup complete."
}

# Function to clean up systemd service and timer
cleanup_systemd() {
    echo "Cleaning up systemd service and timer..."
    systemd_files=("/etc/systemd/system/sisa-timer.service" "/etc/systemd/system/sisa-timer.timer")
    
    for file in "${systemd_files[@]}"; do
        if [ -f "$file" ]; then
            sudo systemctl stop $(basename "$file" .timer)
            sudo systemctl disable $(basename "$file" .timer)
            sudo rm "$file"
            echo "Removed: $file"
        fi
    done
    sudo systemctl daemon-reload
    echo "Systemd cleanup complete."
}

# Function to remove bash and CLI artifacts
cleanup_bash_cli() {
    echo "Cleaning up Bash and CLI test artifacts..."
    bash_artifacts=("/tmp/sisa.sh" "/tmp/SISA.log" "/tmp/AutoSUID.sh" "/tmp/LinEnum.sh" "/tmp/sisa-systemd-timer-marker" "/tmp/pipe-to-shell.sh")
    
    for artifact in "${bash_artifacts[@]}"; do
        if [ -f "$artifact" ]; then
            rm "$artifact"
            echo "Removed: $artifact"
        fi
    done
    echo "Bash and CLI test cleanup complete."
}

# Function to clean up Python-related artifacts
cleanup_python_tests() {
    echo "Cleaning up Python-related artifacts..."
    python_artifacts=("T1059.006-payload" "./Linux_output/Execution/T1059.006_Execution_python.txt")
    
    for artifact in "${python_artifacts[@]}"; do
        if [ -f "$artifact" ]; then
            rm "$artifact"
            echo "Removed: $artifact"
        fi
    done
    echo "Python test cleanup complete."
}

# Function to clean up all execution output logs
cleanup_execution_logs() {
    echo "Cleaning up execution logs..."
    output_folder="./Linux_output/Execution"
    if [ -d "$output_folder" ]; then
        rm -rf "$output_folder"
        echo "Removed: $output_folder"
    fi
    echo "Execution log cleanup complete."
}

# Main cleanup function
main_cleanup() {
    echo "Starting cleanup process..."
    cleanup_at_scheduler
    cleanup_cron_jobs
    cleanup_systemd
    cleanup_bash_cli
    cleanup_python_tests
    cleanup_execution_logs
    echo "All cleanup tasks completed."
}

# Run the main cleanup
main_cleanup
